<?php
namespace app\controllers;
use app\core\controllers;

class AulaController{

    public function index(){
        echo "<h2>Bem-Vindos a primeira aula do Curso</h2>";
    }

}