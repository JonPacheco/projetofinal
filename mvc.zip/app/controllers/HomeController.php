<?php
namespace app\controllers;

class HomeController{
    
   public function index(){
       echo "<br>Controller padrão<br>";
   } 
}
