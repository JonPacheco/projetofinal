<?php

//definição do banco
define("SERVIDOR", "localhost");
define("BANCO", "nomeBanco");
define("USUARIO", "root");
define("SENHA", "");


//definindo controller, método e namespace_controller
define('CONTROLLER_PADRAO', 'home');
define('METODO_PADRAO', 'index');
define('NAMESPACE_CONTROLLER', 'app\\controllers\\');

//qual o caminho do projeto
define('URL_BASE', 'http://localhost/mvc/');
